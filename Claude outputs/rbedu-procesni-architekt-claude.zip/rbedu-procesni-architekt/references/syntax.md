# Kanonická syntax importního MD

Zdroj: `navod-pro-ai-agenta-procesni-architect.md` (RB Universe) + ověřeno proti reálnému
exportu procesu `tvorba-nabidky` (MCP `get_architect_process`, 12. 9. 2026).

## Kostra souboru

```markdown
# <Název procesu>

Krátké intro: k čemu proces je, kdy začíná, kdy končí. Bez odrážek `- **…:**`.

- **Krátký název kroku:**
  *Id:* stabilni-id-z-exportu
  *Role:* Presales Consultant
  *Nástroj:* Pipedrive
  *Navazuje na:* —
  - první odrážka popisu
  - druhá odrážka popisu

- **Další krok:** Popis může být i jednou větou za dvojtečkou.
  *Role:* Learning Designer
  *Navazuje na:* Krátký název kroku
  *Proces:* slug-existujiciho-procesu

## Fáze

- **Akvizice:** od Krátký název kroku do Další krok

## Katalog rolí

- `presales` — Presales Consultant
- `learning-designer` — Learning Designer
```

## Pole kroku

| Řádek | Povinné | Význam |
|---|---|---|
| `- **Název:**` | ano | Titulek kroku, dvojtečka **uvnitř** tučného, v názvu žádná další dvojtečka |
| `*Id:*` | při úpravě ano | `step_key` z exportu; při zakládání může chybět |
| `*Role:*` | doporučeno | Přesný název nebo slug z katalogu rolí |
| `*Nástroj:*` | ne | Systém nebo URL |
| `*Navazuje na:*` | ano | `—` (em dash U+2014) = start, jinak přesný název, Id, nebo slugifikovaný název předchůdce |
| `*Proces:*` | ne | Slug existujícího procesu (název v závorce parser odřízne); víc řádků = víc odkazů |

## Hrany

- Hrany **nevznikají z pořadí odrážek** — jen z `*Navazuje na:*`.
- Cíl se páruje v pořadí **`by_id` → unikátní název kroku → slugify(názvu)**. Takže
  `*Navazuje na:* start` u kroku s `*Id:* start` vytvoří hranu stejně jako přesný název,
  a `*Navazuje na:* zpracovani-podkladu` se spáruje se „Zpracování podkladů“.
  Všechny tři formy jsou platné; **přesný název je preferovaná lidská forma**, Id je bezpečnější
  při úpravě exportu (nerozbije se přejmenováním kroku).
- Právě jeden krok má `*Navazuje na:* —`.
- Fan-out: dva kroky mají stejného předchůdce (v `tvorba-nabidky` jde ze „Zpracování podkladů“
  jak „Design čučky“, tak „Design akademie“).
- Fan-in: jeden krok má víc řádků `*Navazuje na:*`.
- Pořadí kroků v souboru je jen pro čtení, ne pro graf — v reálném exportu je poslední odrážkou
  krok, který navazuje na předposlední.

## MUST NOT (parser nebo review to odmítne)

1. Nevymýšlet kroky, role, nástroje, slugy ani fakta, která nejsou ve vstupu.
2. Jen `.md` — žádné PDF/Word/Docs.
3. Žádné `*Start:* ano` — start se značí `*Navazuje na:* —`.
4. Žádná dvojtečka v názvu kroku ani fáze.
5. Žádné duplicitní názvy kroků (ani duplicitní `*Id:*`).
6. Žádný implicitní řetězec „krok N navazuje na N−1“ bez `*Navazuje na:*`.
7. Žádný `*Proces:*` na neexistující slug.
8. Žádné Markdown tabulky `| … |`.
9. Žádný zaměstnanecký slovník (zaměstnanec, dovolená, mzda) — parťák, nedostupnost, spolupráce.

## Chování importu

- **Bez `*Id:*`**: Universe kroky netiše nemaže, Id si vygeneruje.
- **S `*Id:*`**: krok, který v MD chybí, se **smaže** — proto se v UI potvrzuje diff.
- `## Fáze` chybí → fáze se nemění. Prázdná sekce → fáze se smažou.
- `## Katalog rolí` parser ignoruje (je jen pro tebe a pro validátor).
- Import nemění: screenshoty a komentáře diagramu u spárovaného `*Id:*`, historii verzí,
  publikovanou (živou) verzi — ta se mění až přes Publikovat.
- Jeden soubor = jeden proces. Delší tok rozděl a propoj přes `*Proces:*`.

## Mapování MCP → MD

`get_architect_process(slug)` (ověřeno 12. 9. 2026) vrací u kroku:

| pole v JSONu | řádek v MD |
|---|---|
| `step_id` | `*Id:*` |
| `label` | `- **Label:**` |
| `description_md` | odsazený popis pod krokem (nebo text za dvojtečkou) |
| `role_name` / `role_slug` | `*Role:*` |
| `external_url` | `*Nástroj:*` |
| `edges[].source_step_id` | `*Navazuje na:*` u cílového kroku |
| `outgoing_process_links[].target_slug` | `*Proces:*` |
| `images[]`, `diagram_comments[]` | nemá obdobu v MD — import je u spárovaného `*Id:*` zachová |
| `phases[]` | sekce `## Fáze` (viz níže) |

Převod dělá `scripts/process_to_md.py`.

`step_id` se generuje různě podle toho, jak krok vznikl: v `tvorba-nabidky` je to
`novy-krok`, `novy-krok-2`…, v `tvorba-invoicing-planu` slugifikovaný název
(`volba-rezimu-planovani`). Číslování v Id navíc nemusí sedět s číslem v názvu kroku —
`*Id:* 2-varianta-a` patří kroku „1. Varianta A …“. **Id proto nikdy neodvozuj z názvu**,
vždy ho ber z MCP nebo z exportu.

## Fáze

Struktura v API (ověřeno na `sales-a-delivery-proces-akademie-a-cucky`, v362):
`phases[] = { id, name, position, start_step_key, end_step_key }` — pozor, klíče končí
na `_step_key`, ne `_step_id`; hodnoty odpovídají `step_id` kroků.

V MD: `- **Název fáze:** od <krok> do <krok>`. Rozsah je od–do, ne výčet kroků, takže po
přeorganizování kroků může fáze přestat dávat smysl — po každé změně hran fáze překontroluj.

**Past:** oddělovač je slovo ` do `, které se běžně vyskytuje i v názvech kroků
(„Dokončuji převzetí **do** Realizace“, „Převzetí dealu **do** Delivery“). Takový název
v sekci fází nahraď `*Id:*` kroku — jinak nejde poznat, kde fáze začíná a kde končí.
Generátor to dělá automaticky, validátor nejednoznačnost hlásí.

## Co v procesech reálně je a nesmí se to „opravovat“

Zjištěno na `sales-a-delivery-proces-akademie-a-cucky` (44 kroků, 47 hran, 10 fází):

- **Duplicitní názvy kroků** — dva kroky „Dodávám podklady pro PM“ (jeden KAM, druhý Lektor).
  Návod duplicity zakazuje, produkční data je mají. Odkazuj na ně přes `*Id:*`.
- **Emoji v názvech** — „💰 VYHRÁLI JSME!“, „❌ NEVYŠLO TO 🤷🏻‍♂️“ (včetně ZWJ sekvencí).
  Funguje, ale slugifikace je zahodí, takže odkaz přes slug u nich nespoléhej.
- **Mentiony** `[Pavel Kroupa](rbu-mention:21)` — interní ID uživatele. Kopíruj doslova,
  nikdy nevymýšlej nové číslo a nepřepisuj jméno bez ID.
- **Escapované znaky** — `\+`, `\-` na začátku řádku (aby nevznikla odrážka), `\` na konci
  řádku (tvrdé zalomení), `&gt;`. Vypadá to jako chyba, není.
- **Dvojité mezery v názvu** — „Máme  lead / poptávku“. Neopravuj, rozbil bys párování odkazů.
- **`diagram_comments`** — komentáře u kroku v diagramu, v MD nemají obdobu. Import je
  u spárovaného `*Id:*` zachová; se smazaným krokem zmizí i ony.

## Pozorované detaily z reálného exportu (`tvorba-nabidky`, v38)

- `description_md` kroku = odrážky odsazené dvěma mezerami; vnořené odrážky (4 mezery) fungují.
- `*Id:*` reálně vypadá jako `novy-krok`, `novy-krok-2`, … — Universe je generuje, nejsou to
  slugifikované názvy. Při úpravě je proto **nelze odvodit**, musí přijít z exportu.
- Export z UI píše u odkazu na proces slug i název v závorce:
  `*Proces:* sales-a-delivery-proces-akademie-a-cucky (Sales a Delivery proces - Akademie a čučky)`.
  Parser (`_parse_process_slug`) vezme první token a odřízne `( ) , [ ]` a backtick, takže
  exportní tvar je validní a round-trip ho pokrývá (`test_export_roundtrip`,
  `process_titles_by_slug`). Prakticky: **řádek z exportu nech beze změny**, u nového odkazu
  piš holý slug — to je čistá forma podle návodu.
- Proces může mít prázdné `body_md` a žádné fáze; to je validní stav.
- `&gt;` v popisu (escapované `>`) přežívá round-trip — při úpravě ho nepřepisuj na `>`.
