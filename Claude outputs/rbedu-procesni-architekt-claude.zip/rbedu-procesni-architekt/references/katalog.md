# Katalog rolí a procesů — snapshot

**Snímek k 12. 9. 2026.** Snapshot je fallback, ne SSOT — vždy zkus napřed live zdroj.

Live zdroje (oba ověřeny 12. 9. 2026, fungují):
- role: MCP `list_architect_roles` → slug, name, team_slug, id, is_active
- procesy: MCP `list_architect_processes` → slug, title, status, maintainer
- detail procesu: MCP `get_architect_process(slug)` → viz `syntax.md`, sekce „Mapování MCP → MD“

## Role (23, `list_architect_roles`)

| slug | název | tým |
|---|---|---|
| `potencialni-klient` | (Potenciální) klient | sales |
| `system` | Automatizace / AI / Aplikace | company |
| `cco` | CCO | sales |
| `ceo` | CEO | strategy |
| `cfo` | CFO | finance |
| `co-owner` | Co-Owner | owners |
| `event-manager` | Event Manager | eventy-a-komunity |
| `finance` | Finanční specialista | finance |
| `hod` | Head of Delivery | delivery |
| `uzivatel` | Kdokoliv | company |
| `kam` | Key Account Manager | sales |
| `learning-designer` | Learning Designer | delivery |
| `lektor` | Lektor | delivery |
| `marketing-manager` | Marketing Manager | marketing |
| `office-manager` | Office Manager | operations |
| `people-culture-manager` | People&Culture Manager | people-and-culture |
| `presales` | Presales Consultant | sales |
| `product-owner` | Product Owner | delivery |
| `pm` | Project Manager | delivery |
| `project-support` | Project Support | delivery |
| `sales-support` | Sales Support | sales |
| `ucetni` | Účetní | finance |
| `ucetni-danovy-expert` | Účetní/daňový expert | finance |

Všech 23 mělo `is_active: true`. Tabulka je jen pro čtení agentem — do importního MD
tabulky nikdy nepiš, katalog se tam píše odrážkami `- \`slug\` — Název`.

`role_id` (UUID) už není potřeba mapovat ručně: `get_architect_process` vrací u každého
kroku rovnou `role_slug` i `role_name`. UUID řeš jen tehdy, když role v odpovědi chybí —
pak ji dohledej podle `id` v `list_architect_roles`.

## Procesy (8, `list_architect_processes`)

Jen tyto slugy smí být v `*Proces:*`:

- `generovani-a-realizace-plateb-prijatych-faktur` — Generování a realizace plateb přijatých faktur (schváleno)
- `sales-a-delivery-proces-akademie-a-cucky` — Sales a Delivery proces - Akademie a čučky (draft)
- `tvorba-nabidky` — Tvorba nabídky (schváleno)
- `nedodavani-sluzeb` — Nedodávání služeb (draft)
- `tvorba-nabidkoveho-budgetu-v-allfredovi` — Tvorba nabídkového budgetu v Allfredovi (draft)
- `tvorba-dealu-v-pipedrive-a-prace-s-nim` — Tvorba dealu v Pipedrive a práce s ním (draft)
- `tvorba-invoicing-planu` — Tvorba invoicing plánu (draft)
- `platby-kartou-za-firemni-vydaje-firemni-ci-soukromou` — Platby kartou za firemní výdaje - firemní či soukromou (draft)
