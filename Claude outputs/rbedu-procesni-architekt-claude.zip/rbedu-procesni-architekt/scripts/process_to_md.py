#!/usr/bin/env python3
"""Převod JSON z MCP `get_architect_process` na importní MD pro Procesní architekt.

Použití:
    python3 process_to_md.py proces.json > proces.md
    python3 process_to_md.py proces.json --roles role.json --out proces.md

Vstup `proces.json` = výstup `get_architect_process(slug)` (celý obal s `data`,
nebo rovnou objekt `data`). Volitelný `role.json` = výstup `list_architect_roles`;
z něj se doplní sekce `## Katalog rolí`.

Výstup je vždy **draft k revizi**, ne hotový soubor:
- zkontroluj ho `validate_process_md.py`
- `## Fáze` se generuje z `phases[]`; když fáze neměníš, sekci ze souboru smaž
  (chybějící sekce je nechá být, prázdná sekce je smaže)

Exit kódy: 0 = OK, 1 = vstup nelze zpracovat. Stdlib only, Python 3.9+.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def load(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(data, dict) and "data" in data and "steps" in data.get("data", {}):
        return data["data"]
    return data


def indent_block(text: str, spaces: int = 2) -> list[str]:
    """Odsadí popis kroku.

    Prázdné řádky uvnitř popisu se odsadí taky (na samé mezery), ne na prázdný řádek —
    prázdný řádek by mohl blok kroku ukončit a zbytek textu by se ztratil.
    *Neověřeno:* jak přesně parser víceřádkový popis ukončuje (viz zadání P1-4).
    """
    pad = " " * spaces
    return [pad + line if line.strip() else pad for line in text.splitlines()]


def order_steps(steps: list[dict], edges: list[dict]) -> list[dict]:
    """Topologické pořadí (Kahn), při shodě zachová původní pořadí z API."""
    by_id = {s["step_id"]: s for s in steps}
    incoming: dict[str, int] = {sid: 0 for sid in by_id}
    outgoing: dict[str, list[str]] = {sid: [] for sid in by_id}
    for e in edges:
        src, tgt = e.get("source_step_id"), e.get("target_step_id")
        if src in by_id and tgt in by_id:
            outgoing[src].append(tgt)
            incoming[tgt] += 1

    original = {s["step_id"]: i for i, s in enumerate(steps)}
    ready = sorted([sid for sid, n in incoming.items() if n == 0], key=lambda x: original[x])
    ordered: list[str] = []
    while ready:
        sid = ready.pop(0)
        ordered.append(sid)
        for nxt in outgoing[sid]:
            incoming[nxt] -= 1
            if incoming[nxt] == 0:
                ready.append(nxt)
        ready.sort(key=lambda x: original[x])

    # cyklus nebo nespojené zbytky — doplň v původním pořadí
    for s in steps:
        if s["step_id"] not in ordered:
            ordered.append(s["step_id"])
    return [by_id[sid] for sid in ordered]


def render(proc: dict, roles: list[dict] | None) -> tuple[str, list[str]]:
    warnings: list[str] = []
    steps = proc.get("steps", [])
    edges = proc.get("edges", [])
    if not steps:
        raise ValueError("JSON neobsahuje žádné kroky")

    label_by_id = {s["step_id"]: s["label"] for s in steps}
    seen: dict[str, int] = {}
    for lbl in label_by_id.values():
        seen[lbl] = seen.get(lbl, 0) + 1
    dup = {lbl for lbl, n in seen.items() if n > 1}
    if dup:
        warnings.append(
            "duplicitní názvy kroků (" + ", ".join(sorted(dup)) + ") — odkazy na ně "
            "generuju přes Id, ne názvem"
        )

    def ref(step_id: str) -> str:
        """Odkaz na krok: název, pokud je jednoznačný, jinak Id."""
        label = label_by_id[step_id]
        return step_id if label in dup else label

    def phase_ref(step_id: str) -> str:
        """V `## Fáze` je „ do “ oddělovač, takže název s tímto slovem nahraď Id."""
        label = label_by_id[step_id]
        if label in dup or " do " in label:
            return step_id
        return label

    preds: dict[str, list[str]] = {s["step_id"]: [] for s in steps}
    for e in edges:
        src, tgt = e.get("source_step_id"), e.get("target_step_id")
        if src in label_by_id and tgt in label_by_id:
            preds[tgt].append(src)

    starts = [s["step_id"] for s in steps if not preds[s["step_id"]]]
    if len(starts) != 1:
        warnings.append(
            f"kroků bez předchůdce: {len(starts)} ({', '.join(label_by_id[s] for s in starts) or '—'}). "
            "Import vyžaduje právě jeden start — oprav ručně."
        )

    out: list[str] = [f"# {proc.get('title', '').strip()}", ""]

    body = (proc.get("body_md") or "").strip()
    if body:
        # H1 uvnitř body_md by kolidoval s názvem procesu → degraduj na H2, nemaž text
        body_lines = [("#" + ln) if ln.startswith("# ") else ln for ln in body.splitlines()]
        if body_lines != body.splitlines():
            warnings.append(
                "v `body_md` byl H1 nadpis převeden na H2 (kolize s názvem procesu) — "
                "zkontroluj, jestli to tak chceš, případně to oprav v UI"
            )
        cleaned = "\n".join(body_lines).strip()
        if cleaned:
            out += [cleaned, ""]

    for s in order_steps(steps, edges):
        sid = s["step_id"]
        label = s["label"].strip()
        desc = (s.get("description_md") or "").strip()
        inline = ""
        block: list[str] = []
        if desc:
            if desc.lstrip().startswith(("-", "*", "1.")):
                block = indent_block(desc)
            else:
                lines = desc.splitlines()
                inline = " " + lines[0].strip()
                if len(lines) > 1:
                    block = indent_block("\n".join(lines[1:]).strip())

        out.append(f"- **{label}:**{inline}")
        out.append(f"  *Id:* {sid}")

        role = s.get("role_name") or s.get("role_slug")
        if role:
            out.append(f"  *Role:* {role}")
        elif s.get("role_id"):
            warnings.append(f"krok „{label}“: role jen jako UUID {s['role_id']} — doplň ručně")

        if s.get("external_url"):
            out.append(f"  *Nástroj:* {s['external_url']}")

        if preds[sid]:
            for p in preds[sid]:
                out.append(f"  *Navazuje na:* {ref(p)}")
        else:
            out.append("  *Navazuje na:* \u2014")

        for link in s.get("outgoing_process_links") or []:
            target = link.get("target_slug")
            if target:
                out.append(f"  *Proces:* {target}")

        out += block
        out.append("")

        attachments = []
        if s.get("images"):
            attachments.append(f"{len(s['images'])} obrázek/ů")
        if s.get("diagram_comments"):
            attachments.append(f"{len(s['diagram_comments'])} komentář/ů v diagramu")
        if attachments:
            warnings.append(
                f"krok „{label}“ má {' a '.join(attachments)} — import je u spárovaného Id "
                "zachová, ale smazáním kroku je ztratíš"
            )

    phases = sorted(proc.get("phases") or [], key=lambda p: p.get("position", 0))
    if phases:
        out += ["## Fáze", ""]
        for ph in phases:
            start, end = ph.get("start_step_key"), ph.get("end_step_key")
            if start not in label_by_id or end not in label_by_id:
                warnings.append(
                    f"fáze „{ph.get('name')}“ odkazuje na krok mimo proces "
                    f"({start} → {end}) — vynechána, zkontroluj ji v UI"
                )
                continue
            name = (ph.get("name") or "").strip()
            if ":" in name:
                warnings.append(
                    f"fáze „{name}“ obsahuje dvojtečku — v názvu fáze není povolená, uprav ji"
                )
            out.append(f"- **{name}:** od {phase_ref(start)} do {phase_ref(end)}")
        out.append("")
        warnings.append(
            f"sekce `## Fáze` vygenerována z {len(phases)} fází — pokud ji ze souboru smažeš, "
            "fáze se importem nezmění; prázdná sekce je naopak smaže"
        )

    if roles:
        out += ["## Katalog rolí", ""]
        for r in sorted(roles, key=lambda x: x.get("name", "")):
            out.append(f"- `{r.get('slug')}` — {r.get('name')}")
        out.append("")

    return "\n".join(out).rstrip() + "\n", warnings


def main() -> int:
    ap = argparse.ArgumentParser(description="get_architect_process JSON → importní MD")
    ap.add_argument("path", help="JSON z get_architect_process")
    ap.add_argument("--roles", help="JSON z list_architect_roles (doplní ## Katalog rolí)")
    ap.add_argument("--out", help="cílový .md (výchozí: stdout)")
    args = ap.parse_args()

    try:
        proc = load(Path(args.path))
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"CHYBA: vstup nelze načíst — {exc}", file=sys.stderr)
        return 1

    roles = None
    if args.roles:
        try:
            raw = json.loads(Path(args.roles).read_text(encoding="utf-8"))
            roles = raw.get("results", raw) if isinstance(raw, dict) else raw
        except (OSError, json.JSONDecodeError) as exc:
            print(f"CHYBA: role nelze načíst — {exc}", file=sys.stderr)
            return 1

    try:
        md, warnings = render(proc, roles)
    except ValueError as exc:
        print(f"CHYBA: {exc}", file=sys.stderr)
        return 1

    if args.out:
        Path(args.out).write_text(md, encoding="utf-8")
        print(f"Zapsáno: {args.out}", file=sys.stderr)
    else:
        sys.stdout.write(md)

    for w in warnings:
        print(f"! {w}", file=sys.stderr)
    print(
        "! Draft k revizi — spusť validate_process_md.py a projdi diff, než ho nahraješ.",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
