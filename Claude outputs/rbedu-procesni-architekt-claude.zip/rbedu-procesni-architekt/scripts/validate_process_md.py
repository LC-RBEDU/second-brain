#!/usr/bin/env python3
"""Validace Markdown souboru pro import do Procesního architekta (RB Universe).

Použití:
    python3 validate_process_md.py proces.md
    python3 validate_process_md.py proces.md --slugs tvorba-nabidky,nedodavani-sluzeb
    python3 validate_process_md.py proces.md --json

Exit kódy: 0 = bez chyb (warningy povoleny), 1 = chyby, 2 = soubor nelze přečíst.
Stdlib only, Python 3.9+.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import unicodedata
from pathlib import Path

EM_DASH = "\u2014"

STEP_RE = re.compile(r"^-\s+\*\*(?P<label>.+?):\*\*(?P<inline>.*)$")
FIELD_RE = re.compile(r"^\s*\*(?P<key>[^:*]+):\*\s*(?P<val>.*)$")
CATALOG_RE = re.compile(r"^-\s+`(?P<slug>[^`]+)`\s+[—-]\s+(?P<name>.+?)\s*$")
PHASE_RE = re.compile(r"^-\s+\*\*(?P<name>.+?):\*\*\s*od\s+(?P<rest>.+?)\s*$")

BAD_WORDS = {
    "zaměstnanec": "parťák",
    "zaměstnanc": "parťák",
    "zaměstnanci": "parťák",
    "dovolen": "nedostupnost",
    "mzda": "odměna / spolupráce",
    "mzdy": "odměna / spolupráce",
    "pracovní poměr": "spolupráce",
}

MULTI_FIELDS = {"Navazuje na", "Proces"}
KNOWN_FIELDS = {"Id", "Role", "Nástroj", "Navazuje na", "Proces"}


def slugify(text: str) -> str:
    """Přibližná náhrada slugifikace v Universe (unidecode + kebab-case)."""
    norm = unicodedata.normalize("NFKD", text)
    ascii_text = "".join(c for c in norm if not unicodedata.combining(c))
    ascii_text = ascii_text.encode("ascii", "ignore").decode("ascii").lower()
    return re.sub(r"-+", "-", re.sub(r"[^a-z0-9]+", "-", ascii_text)).strip("-")


def clean_process_slug(value: str) -> str:
    """`cilovy-proces (Cílový)` → `cilovy-proces` — stejně jako `_parse_process_slug`.

    Parser bere první token a odřízne `(`, `)`, `,`, `[`, `]` a backtick,
    takže exportní tvar se slugem i názvem v závorce je validní vstup.
    """
    token = value.strip().split()[0] if value.strip() else ""
    return token.strip("()[],`")


class Report:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def err(self, msg: str) -> None:
        self.errors.append(msg)

    def warn(self, msg: str) -> None:
        self.warnings.append(msg)


def strip_code_fences(lines: list[str]) -> list[bool]:
    """Vrátí masku: True = řádek je uvnitř code fence."""
    inside = False
    mask = []
    for line in lines:
        if line.strip().startswith("```"):
            mask.append(True)
            inside = not inside
            continue
        mask.append(inside)
    return mask


def parse(text: str, rep: Report) -> dict:
    lines = text.splitlines()
    fence = strip_code_fences(lines)

    steps: list[dict] = []
    catalog: dict[str, str] = {}
    phases: list[dict] = []
    section = None
    phase_section_present = False
    phase_section_empty = True
    current: dict | None = None
    h1_count = 0

    for idx, raw in enumerate(lines, start=1):
        if fence[idx - 1]:
            continue
        line = raw.rstrip()

        if line.startswith("# "):
            h1_count += 1
            section = "intro"
            current = None
            continue
        if line.startswith("## "):
            heading = line[3:].strip().lower()
            if heading.startswith("fáze") or heading.startswith("faze"):
                section = "phases"
                phase_section_present = True
            elif "katalog rol" in heading:
                section = "catalog"
            else:
                section = "other"
            current = None
            continue

        if section == "catalog":
            m = CATALOG_RE.match(line)
            if m:
                catalog[m.group("slug").strip()] = m.group("name").strip()
            continue

        if section == "phases":
            if line.strip():
                phase_section_empty = False
            m = PHASE_RE.match(line)
            if m:
                phases.append(
                    {
                        "name": m.group("name").strip(),
                        "rest": m.group("rest").strip(),
                        "line": idx,
                    }
                )
            elif line.strip().startswith("- **"):
                rep.err(f"ř. {idx}: fáze nemá tvar `- **Název:** od X do Y` → {line.strip()}")
            continue

        m = STEP_RE.match(line)
        if m and section in (None, "intro", "other"):
            label = m.group("label").strip()
            current = {
                "label": label,
                "inline": m.group("inline").strip(),
                "line": idx,
                "fields": {},
                "desc": [],
            }
            steps.append(current)
            continue

        fm = FIELD_RE.match(line)
        if fm and current is not None:
            key = fm.group("key").strip()
            val = fm.group("val").strip()
            if key not in KNOWN_FIELDS:
                rep.warn(f"ř. {idx}: neznámé pole *{key}:* — parser ho ignoruje")
            current["fields"].setdefault(key, []).append({"val": val, "line": idx})
            continue

        if current is not None and raw[:1] in (" ", "\t", "-") and line.strip():
            current["desc"].append(line)

    return {
        "h1_count": h1_count,
        "steps": steps,
        "catalog": catalog,
        "phases": phases,
        "phase_section_present": phase_section_present,
        "phase_section_empty": phase_section_empty,
        "lines": lines,
        "fence": fence,
    }


def validate(doc: dict, rep: Report, known_slugs: set[str] | None) -> None:
    steps = doc["steps"]

    if doc["h1_count"] == 0:
        rep.err("chybí `# Název procesu` (H1)")
    elif doc["h1_count"] > 1:
        rep.err(f"víc než jeden H1 ({doc['h1_count']}) — jeden soubor = jeden proces")

    if not steps:
        rep.err("soubor neobsahuje žádný krok `- **Název:**`")
        return

    labels: dict[str, int] = {}
    dup_labels: set[str] = set()
    ids: dict[str, int] = {}
    for s in steps:
        label = s["label"]
        if ":" in label:
            rep.err(f"ř. {s['line']}: název kroku obsahuje dvojtečku → {label}")
        if label in labels:
            dup_labels.add(label)
        else:
            labels[label] = s["line"]
        if "  " in label:
            rep.warn(f"ř. {s['line']}: název kroku obsahuje dvojitou mezeru → „{label}“")

        for key, entries in s["fields"].items():
            if key not in MULTI_FIELDS and len(entries) > 1:
                rep.err(f"krok „{label}“: pole *{key}:* je uvedeno {len(entries)}×")

        id_entries = s["fields"].get("Id", [])
        if id_entries:
            sid = id_entries[0]["val"]
            if sid in ids:
                rep.err(f"ř. {s['line']}: duplicitní *Id:* `{sid}` (už na ř. {ids[sid]})")
            else:
                ids[sid] = s["line"]

        if not s["fields"].get("Role"):
            rep.warn(f"krok „{label}“: chybí *Role:*")
        if not s["inline"] and not s["desc"]:
            rep.warn(f"krok „{label}“: prázdný popis")

    with_id = [s for s in steps if s["fields"].get("Id")]
    if with_id and len(with_id) != len(steps):
        rep.warn(
            f"{len(with_id)} z {len(steps)} kroků má *Id:* — to je v pořádku jen tehdy, "
            "když kroky bez Id jsou nové. Zkontroluj."
        )
    if with_id:
        rep.warn(
            "režim s *Id:* — každý krok, který v tomto souboru chybí, Universe SMAŽE. "
            "Ověř proti exportu a vypiš to do preview."
        )

    # start + hrany
    # Resolve cíle jde v Universe v pořadí: by_id → unikátní label → slugify(label).
    id_to_label: dict[str, str] = {}
    for s in steps:
        for e in s["fields"].get("Id", []):
            id_to_label[e["val"]] = s["label"]

    slug_index: dict[str, list[str]] = {}
    for s in steps:
        slug_index.setdefault(slugify(s["label"]), []).append(s["label"])

    def resolve(val: str) -> tuple[str | None, str]:
        if val in id_to_label:
            return id_to_label[val], "id"
        if val in dup_labels:
            return None, "duplicate"
        if val in labels:
            return val, "label"
        candidates = slug_index.get(slugify(val), [])
        if len(candidates) == 1 and candidates[0] not in dup_labels:
            return candidates[0], "slug"
        if len(candidates) > 1 or (candidates and candidates[0] in dup_labels):
            return None, "ambiguous"
        return None, "missing"

    if dup_labels:
        if id_to_label:
            rep.warn(
                "duplicitní názvy kroků: "
                + ", ".join(f"„{x}“" for x in sorted(dup_labels))
                + " — odkazuj na ně jen přes *Id:*, ne názvem"
            )
        else:
            rep.err(
                "duplicitní názvy kroků: "
                + ", ".join(f"„{x}“" for x in sorted(dup_labels))
                + " — bez *Id:* je nelze jednoznačně adresovat, přejmenuj je"
            )

    starts = []
    targets_of: dict[str, list[str]] = {s["label"]: [] for s in steps}
    has_incoming: set[str] = set()
    for s in steps:
        entries = s["fields"].get("Navazuje na", [])
        if not entries:
            rep.err(f"krok „{s['label']}“: chybí *Navazuje na:*")
            continue
        for e in entries:
            val = e["val"].strip()
            if val in (EM_DASH, ""):
                if val == "":
                    rep.err(f"ř. {e['line']}: prázdné *Navazuje na:* — start se značí `—` (em dash)")
                else:
                    starts.append(s["label"])
                continue
            if val in {"-", "--", "–"}:
                rep.err(
                    f"ř. {e['line']}: start musí být em dash `—` (U+2014), ne `{val}`"
                )
                starts.append(s["label"])
                continue
            pred, how = resolve(val)
            if how in ("ambiguous", "duplicate"):
                rep.err(
                    f"ř. {e['line']}: *Navazuje na:* „{val}“ je nejednoznačné "
                    "(víc kroků stejného názvu) — odkaž přes *Id:*"
                )
                continue
            if pred is None:
                rep.err(
                    f"ř. {e['line']}: *Navazuje na:* „{val}“ neodpovídá žádnému názvu kroku ani Id"
                )
                continue
            if how == "slug":
                rep.warn(
                    f"ř. {e['line']}: „{val}“ se spároval až přes slugifikaci názvu "
                    f"(→ „{pred}“). Funguje to, ale čitelnější je přesný název nebo Id."
                )
            if pred == s["label"]:
                rep.err(f"krok „{s['label']}“ navazuje sám na sebe")
                continue
            targets_of[pred].append(s["label"])
            has_incoming.add(s["label"])

    if len(starts) == 0:
        rep.err("žádný startovní krok — právě jeden krok musí mít `*Navazuje na:* —`")
    elif len(starts) > 1:
        rep.err("víc startovních kroků: " + ", ".join(f"„{x}“" for x in starts))

    for s in steps:
        if s["label"] not in has_incoming and s["label"] not in starts:
            rep.err(f"krok „{s['label']}“ nemá předchůdce ani není start (sirotek)")

    # cykly
    color: dict[str, int] = {s["label"]: 0 for s in steps}

    def dfs(node: str, stack: list[str]) -> None:
        color[node] = 1
        for nxt in targets_of.get(node, []):
            if color.get(nxt) == 1:
                cycle = " → ".join(stack[stack.index(nxt):] + [nxt]) if nxt in stack else f"{node} → {nxt}"
                rep.warn(f"cyklus v grafu: {cycle} — Universe to unese, ale ověř, že je to záměr")
            elif color.get(nxt) == 0:
                dfs(nxt, stack + [nxt])
        color[node] = 2

    sys.setrecursionlimit(10000)
    for s in steps:
        if color[s["label"]] == 0:
            dfs(s["label"], [s["label"]])

    # fáze
    for ph in doc["phases"]:
        if ":" in ph["name"]:
            rep.err(f"ř. {ph['line']}: název fáze obsahuje dvojtečku → {ph['name']}")
        rest = ph["rest"]
        # „od X do Y“ — X i Y mohou samy obsahovat „ do “ (např. „Dokončuji převzetí do Realizace“),
        # takže zkus všechny možné dělicí body a nech jen ty, kde oba kroky existují.
        parts = rest.split(" do ")
        valid = []
        for i in range(1, len(parts)):
            left = " do ".join(parts[:i]).strip()
            right = " do ".join(parts[i:]).strip()
            if resolve(left)[0] and resolve(right)[0]:
                valid.append((left, right))
        if not valid:
            rep.err(
                f"ř. {ph['line']}: fáze „{ph['name']}“ — „{rest}“ neodkazuje na existující kroky "
                "(očekává se `od <krok> do <krok>`)"
            )
        elif len(valid) > 1:
            rep.warn(
                f"ř. {ph['line']}: fáze „{ph['name']}“ jde rozdělit víc způsoby "
                f"({len(valid)}×) — název kroku obsahuje slovo „do“. Ověř, že Universe vybere "
                "stejnou variantu, nebo kroky přejmenuj."
            )
    if doc["phase_section_present"] and doc["phase_section_empty"]:
        rep.warn("prázdná sekce `## Fáze` — při importu se fáze SMAŽOU. Chceš to?")

    # role vs. katalog
    catalog = doc["catalog"]
    if catalog:
        allowed = set(catalog.keys()) | set(catalog.values())
        for s in steps:
            for e in s["fields"].get("Role", []):
                if e["val"] and e["val"] not in allowed:
                    rep.err(
                        f"ř. {e['line']}: role „{e['val']}“ není v `## Katalog rolí` v tomto souboru"
                    )
    else:
        rep.warn("soubor nemá `## Katalog rolí` — role nelze ověřit proti katalogu")

    # odkazy na procesy
    for s in steps:
        for e in s["fields"].get("Proces", []):
            slug = clean_process_slug(e["val"])
            if not slug:
                rep.err(f"ř. {e['line']}: prázdný *Proces:*")
                continue
            if not re.fullmatch(r"[a-z0-9-]+", slug):
                rep.err(
                    f"ř. {e['line']}: *Proces:* „{slug}“ nevypadá jako slug (jen a-z, 0-9, pomlčka)"
                )
            elif known_slugs is not None and slug not in known_slugs:
                rep.err(f"ř. {e['line']}: slug `{slug}` není v seznamu existujících procesů")
            elif known_slugs is None:
                rep.warn(
                    f"slug `{slug}` neověřen — spusť `list_architect_processes` a předej --slugs"
                )

    # zakázané konstrukce v celém souboru
    for idx, raw in enumerate(doc["lines"], start=1):
        if doc["fence"][idx - 1]:
            continue
        line = raw.strip()
        if line.startswith("|") and line.endswith("|"):
            rep.err(f"ř. {idx}: Markdown tabulka `| … |` není povolená")
        if "*Start:*" in raw:
            rep.err(f"ř. {idx}: `*Start:*` se nepoužívá — start je `*Navazuje na:* —`")
        low = raw.lower()
        for bad, better in BAD_WORDS.items():
            if bad in low:
                rep.warn(f"ř. {idx}: zaměstnanecký slovník „{bad}“ → použij „{better}“")
                break


def main() -> int:
    ap = argparse.ArgumentParser(description="Validace MD pro Procesní architekt RB Universe")
    ap.add_argument("path", help="cesta k .md souboru")
    ap.add_argument(
        "--slugs",
        help="čárkou oddělený seznam existujících slugů procesů (z list_architect_processes)",
    )
    ap.add_argument("--json", action="store_true", help="výstup jako JSON")
    args = ap.parse_args()

    path = Path(args.path)
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"CHYBA: soubor nelze přečíst — {exc}", file=sys.stderr)
        return 2

    if path.suffix.lower() != ".md":
        print("CHYBA: importovat lze jen .md", file=sys.stderr)
        return 1

    known = None
    if args.slugs:
        known = {s.strip() for s in args.slugs.split(",") if s.strip()}

    rep = Report()
    doc = parse(text, rep)
    validate(doc, rep, known)

    if args.json:
        print(
            json.dumps(
                {
                    "file": str(path),
                    "steps": len(doc["steps"]),
                    "errors": rep.errors,
                    "warnings": rep.warnings,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 1 if rep.errors else 0

    print(f"Soubor: {path}")
    print(f"Kroků: {len(doc['steps'])} · fází: {len(doc['phases'])} · rolí v katalogu: {len(doc['catalog'])}")
    if rep.errors:
        print(f"\nCHYBY ({len(rep.errors)}):")
        for e in rep.errors:
            print(f"  ✗ {e}")
    if rep.warnings:
        print(f"\nWARNINGY ({len(rep.warnings)}):")
        for w in rep.warnings:
            print(f"  ! {w}")
    if not rep.errors and not rep.warnings:
        print("\nOK — bez chyb a warningů.")
    elif not rep.errors:
        print("\nOK — bez chyb (viz warningy).")
    return 1 if rep.errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
