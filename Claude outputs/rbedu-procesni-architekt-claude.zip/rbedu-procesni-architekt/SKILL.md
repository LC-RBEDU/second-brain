---
name: rbedu-procesni-architekt
description: "Připraví jeden Markdown soubor ve formátu importovatelném do Procesního architekta v RB Universe (universe.redbuttonedu.cz) — nový proces i update existujícího přes export s `*Id:*`. Použij vždy, když jde o firemní proces a Universe: „napiš proces“, „zmapuj proces“, „proces do Universe“, „MD pro Procesní architekt“, „import procesu“, „aktualizuj proces (slug)“, „přidej krok do procesu“, „přepiš přepis schůzky na proces“, „zmapuj, jak se u nás dělá X“. Použij i tehdy, když uživatel jen popíše postup a zmíní, že to má být proces — formát importu je striktní a bez tohoto skillu ho odhadneš špatně. Vyžaduje MCP RB Universe (`list_architect_processes`, `list_architect_roles`, `get_architect_process`) a Python 3.9+ pro skripty.\n"
---

# Procesní architekt — příprava MD pro import

Universe `.md` **jen parsuje** — nepřepisuje ho AI. Cokoli si vymyslíš, se v Architektu
objeví jako fakt, který nikdo neřekl. Proto platí dvě věci nad všemi ostatními:
**nevymýšlej kroky, role, nástroje ani slugy** a **před odevzdáním souboru ukaž preview**.

## Co skill dělá a co ne

Dělá: draft `.md`, validaci syntaxe, diff proti aktuálnímu stavu procesu, seznam otevřených otázek.

Nedělá: **neimportuje**. Import je ruční krok uživatele v UI (Nový proces → Import, nebo
Úprava procesu → nahrát `.md` → náhled diffu → Aplikovat → Publikovat zvlášť). Nikdy netvrď,
že je proces nahraný nebo publikovaný.

## Krok 1 — urči režim

| Situace | Režim |
|---|---|
| Proces v Universe ještě není | **A — nový** |
| Proces existuje (slug je v `list_architect_processes`) | **B — úprava** |

Vždy si napřed zavolej `list_architect_processes` (MCP RB Universe, produkční data).
Dává ti tři věci: jestli proces existuje, přesné slugy pro `*Proces:*` odkazy a status
(`draft` / `schvaleno`). Když najdeš podobný název, zeptej se uživatele, jestli jde o update —
nezakládej duplicitní proces.

U procesu se statusem `schvaleno` se ptej vždy: úprava schváleného procesu se dotkne něčeho,
co už tým bere jako platné.

## Krok 2 — sesbírej vstup

Potřebuješ minimálně: název procesu, kdy začíná a kdy končí, a zdroj (přepis schůzky,
poznámky, dokument, seznam kroků). Co ve vstupu není, se do souboru nedostane.

Chybějící role, nástroj nebo navazující proces **není důvod něco doplnit odhadem** — je to
položka do sekce „Otevřené otázky“ v preview.

## Krok 3 — režim A (nový proces)

1. Napiš `.md` podle `references/syntax.md`. `*Id:*` **vynech** — Universe je vyrobí.
2. `*Role:*` ber z `list_architect_roles` (MCP vrací slug i název). Když volání selže,
   použij snapshot v `references/katalog.md` a v preview napiš, že jde o snímek, ne o živý stav.
3. `*Proces:*` dej jen na slug, který jsi právě viděl v `list_architect_processes`.
   Zmínku o procesu, který ještě neexistuje, dej do textu kroku.
4. `## Fáze` piš jen tehdy, když je uživatel zadal nebo z podkladu jednoznačně plynou.

## Krok 4 — režim B (úprava existujícího)

Zdroj struktury je `get_architect_process(slug)`. Vrací všechno, co MD potřebuje:
`step_id` → `*Id:*`, `label`, `description_md`, `role_name` / `role_slug` → `*Role:*`,
`external_url` → `*Nástroj:*`, `edges` → `*Navazuje na:*`, `outgoing_process_links` → `*Proces:*`,
`phases` → `## Fáze`.

1. Ulož JSON z MCP do souboru a vygeneruj kostru:
   ```bash
   python3 scripts/process_to_md.py proces.json --roles role.json --out proces.md
   ```
   Generátor řadí kroky topologicky, doplní fan-in jako víc řádků `*Navazuje na:*`
   a vypíše na stderr, co potřebuje pozornost (obrázky, komentáře v diagramu, chybějící role,
   fáze). Výstup je **draft k revizi**, ne hotový soubor.
2. **Ulož si kopii jako baseline** a teprve druhou kopii uprav:
   ```bash
   cp proces.md baseline.md      # uprav proces.md
   diff -u baseline.md proces.md # přesně tohle patří do preview
   ```
   U procesu o 40 krocích je to jediný způsob, jak poznat, že jsi omylem nesáhl někam jinam.
3. Ruční úpravu textů dělej až v tom souboru. Popisy, které neměníš, nech doslova —
   nepřeformulovávej cizí texty „aby zněly líp“. To platí i pro věci, které vypadají jako
   překlep nebo chyba: `\+`, `\-` na začátku řádku, `\` na konci řádku, `&gt;`, dvojité
   mezery v názvu kroku a mentiony `[Jméno](rbu-mention:21)`. Escapování drží formátování
   a mention ID patří konkrétnímu člověku — přepsat je znamená rozbít výstup.
4. Alternativa, když chceš přesně to, co vidí uživatel v UI: Úprava procesu →
   *Stáhnout aktuální proces jako MD*. Export obsahuje navíc `## Katalog rolí`.
   Stáhnout ho za uživatele neumíš — musíš si o něj říct.

Pravidla, která platí v obou případech:

- U existujících kroků **zachovej `*Id:*` beze změny**. Nové kroky nech bez Id.
- **Krok, který v souboru chybí, Universe v Id režimu smaže** — i s jeho obrázky a komentáři
  v diagramu. Každé takové smazání vypiš v preview zvlášť a nech ho potvrdit. Bez explicitního
  pokynu kroky neodstraňuj.
- `## Fáze`: generátor sekci vypíše z `phases[]`. Když fáze neměníš, **smaž ji ze souboru** —
  chybějící sekce fáze nechá být, prázdná sekce je smaže.
- **Duplicitní názvy kroků existují** (v `sales-a-delivery-proces-akademie-a-cucky` jsou dva
  kroky „Dodávám podklady pro PM“). Na takový krok se nedá odkázat názvem — odkazuj přes `*Id:*`.

## Krok 5 — validace

```bash
python3 scripts/process_to_md.py proces.json --roles role.json --out proces.md   # jen režim B
python3 scripts/validate_process_md.py proces.md --slugs SLUG1,SLUG2,... (z list_architect_processes)
```

Kontroluje mimo jiné: právě jeden start (`*Navazuje na:* —`), jednoznačné názvy i Id,
existující cíle hran, rozsahy fází, zákaz `*Start:*`, zákaz tabulek `| … |`, dvojtečku
v názvu kroku, sirotky, cykly, zaměstnanecký slovník a shodu rolí s `## Katalog rolí`.

Exit 1 = chyby. Soubor s chybami neodevzdávej — oprav a spusť znovu.
Warningy vypiš uživateli, ať se rozhodne sám.

## Krok 6 — preview (povinné, před odevzdáním)

Ukaž v chatu:

- **Kroky:** `Název — Role — Nástroj` v pořadí, v jakém budou v souboru
- **Graf:** `Krok A → Krok B`, fan-in / fan-out vypiš explicitně, start označ
- **Diff** (režim B): přidané / změněné / **smazané** kroky a změny hran
- **Odkazy na jiné procesy:** slug + jestli existuje
- **Otevřené otázky:** co jsi nevěděl a co jsi proto vynechal
- **Výstup validátoru:** OK / seznam warningů

Teprve po schválení odevzdej soubor ke stažení.

## Jazyk a forma obsahu

- Česky, imperativ, druhá osoba: „Zkontroluj podklady…“, „Na Slacku odepiš…“.
- Popis kroku = odrážky odsazené dvěma mezerami pod řádkem kroku (tak vypadá export z Universe).
  Jedna věta za `- **Název:**` je taky validní, ale ve většině RB EDU procesů jsou odrážky.
- Nikdy zaměstnanecký slovník: **parťák** (ne zaměstnanec), **nedostupnost** (ne dovolená),
  **spolupráce** (ne pracovní poměr).
- URL v lomených závorkách: `https://…` v lomených závorkách.
- Název kroku bez dvojtečky, krátký, slovesný („Zpracování podkladů“, „Publikování nabídky“).

Detaily syntaxe, pole kroku a kanonický příklad: `references/syntax.md`.
Katalog rolí a slugy existujících procesů: `references/katalog.md`.

## Handoff

Ty připravíš a zvaliduješ soubor. Uživatel ho stáhne, v UI nahraje, projde náhled diffu,
aplikuje a publikuje. Publikace je vždy vědomé rozhodnutí člověka — nikdy ji nepobízej
ani nepředpokládej, že proběhla.
